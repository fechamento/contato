import Head from 'next/head';
import { useState } from 'react';
import styles from '../styles/globals.css';

export default function Home() {
  const [formData, setFormData] = useState({ nome: '', email: '', telefone: '', mensagem: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('Enviando...');

    const res = await fetch('/api/lead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    setStatus(data.message || 'Lead enviado!');
  };

  return (
    <>
      <Head>
        <title>Imóveis & Co — Encontre seu lar ideal</title>
      </Head>

      <section className="hero">
        <div className="overlay">
          <h1>Encontre o imóvel dos seus sonhos</h1>
          <p>Casas e apartamentos selecionados com requinte e sofisticação.</p>
          <a href="#contato" className="cta">Fale com um consultor</a>
        </div>
      </section>

      <section className="imoveis">
        <h2>Imóveis em destaque</h2>
        <div className="cards">
          <div className="card">
            <img src="/casa1.jpg" alt="Casa moderna" />
            <h3>Casa moderna em condomínio</h3>
            <p>3 suítes, piscina e área gourmet.</p>
          </div>
          <div className="card">
            <img src="/casa2.jpg" alt="Apartamento vista mar" />
            <h3>Apartamento vista mar</h3>
            <p>2 dormitórios, varanda e lazer completo.</p>
          </div>
          <div className="card">
            <img src="/casa3.jpg" alt="Cobertura de luxo" />
            <h3>Cobertura de luxo</h3>
            <p>Localização nobre e acabamento premium.</p>
          </div>
        </div>
      </section>

      <section id="contato" className="contato">
        <h2>Fale conosco</h2>
        <form onSubmit={handleSubmit}>
          <input type="text" name="nome" placeholder="Seu nome" required onChange={handleChange} />
          <input type="email" name="email" placeholder="Seu e-mail" required onChange={handleChange} />
          <input type="tel" name="telefone" placeholder="Telefone / WhatsApp" required onChange={handleChange} />
          <textarea name="mensagem" placeholder="Mensagem" onChange={handleChange}></textarea>
          <button type="submit">Enviar</button>
          <p className="status">{status}</p>
        </form>
      </section>

      <footer>
        <p>© {new Date().getFullYear()} Imóveis & Co — Todos os direitos reservados.</p>
      </footer>
    </>
  );
}