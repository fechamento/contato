import sendgrid from '@sendgrid/mail';

sendgrid.setApiKey(process.env.SENDGRID_API_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Método não permitido' });

  const { nome, email, telefone, mensagem } = req.body;

  try {
    await sendgrid.send({
      to: process.env.SENDGRID_TO,
      from: process.env.SENDGRID_FROM,
      subject: `Novo lead de ${nome}`,
      text: `Nome: ${nome}\nEmail: ${email}\nTelefone: ${telefone}\nMensagem: ${mensagem}`,
    });
    res.status(200).json({ message: 'Lead enviado com sucesso!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao enviar lead.' });
  }
}